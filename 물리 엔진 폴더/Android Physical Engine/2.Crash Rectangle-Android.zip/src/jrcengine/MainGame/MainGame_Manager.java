// �� ��ü�� ���� �ν��Ͻ��� �����ϰ�
// �� �����Ӹ��� ��ü�� ������Ʈ �ϸ� ��ü�� Bob ������ �浹�� �˻��ϰ� ������ ����
package jrcengine.MainGame;

import java.util.Random;

import jrcengine.Interface.Screen_Manager;
import jrcengine.Manage.Manage_Settings;
import jrcengine.Math.Math_Vector;
import android.util.Log;

public class MainGame_Manager extends Screen_Manager {

	private final int world_Width;
	private final int world_Height;
	private Random rnd;
	private Object o[];
	private Object obstacles[];
	private RigidBody2d ob;
	private RigidBody2d craft;

	public MainGame_Manager(int world_Width, int world_Height) {

		this.world_Width = world_Width;
		this.world_Height = world_Height;
		this.o = new Object[Manage_Settings.ObjectNumber];
		this.obstacles = new Object[Manage_Settings.ObstacleNumber];
		this.rnd = new Random();

		this.ob = new RigidBody2d(Manage_Settings.GAME_WIDTH / 2 - 100,
				Manage_Settings.GAME_HEIGHT / 2);
		this.craft = new RigidBody2d(Manage_Settings.GAME_WIDTH / 2 - 100,
				Manage_Settings.GAME_HEIGHT / 2);
		ob.vPosition.x = Manage_Settings.GAME_WIDTH / 2 - 100;
		ob.vPosition.y = Manage_Settings.GAME_HEIGHT / 2;
		ob.fOrientation = 0;

		craft.vPosition.x = Manage_Settings.GAME_WIDTH / 2;
		craft.vPosition.y = Manage_Settings.GAME_HEIGHT / 2;
		craft.fOrientation = 180f;

		generate();

	}

	// ���� ������ ����
	@Override
	protected void generate() {

		for (int i = 0; i < Manage_Settings.ObjectNumber; i++)
			o[i] = new Object(Manage_Settings.GAME_WIDTH / 2 - 20
					+ rnd.nextInt(40), Manage_Settings.GAME_HEIGHT - 10);

		for (int i = 0; i < Manage_Settings.ObstacleNumber; i++) {
			obstacles[i] = new Object(Manage_Settings.GAME_WIDTH / 2 - 50
					+ rnd.nextInt(80), Manage_Settings.GAME_HEIGHT / 2 - 20
					+ rnd.nextInt(40), Manage_Settings.ObstacleSize);
			obstacles[i].setfMass(100f);
		}

	}

	@Override
	public void update(MainGame_Renderer rander, float deltaTime,
			float accel_X, float accel_Y, float click_X, float click_Y) {

		update_Objections(deltaTime, accel_X, accel_Y, click_X, click_Y);
		update_checkCollisions(deltaTime);
	}

	@Override
	protected void update_Objections(float deltaTime, float accel_X,
			float accel_Y, float click_X, float click_Y) {
		updateCycle(deltaTime);
		updateCraft(deltaTime);
	}

	private void updateCraft(float deltaTime) {
		boolean tryAgain = true;
		int check = 0;
		float dtime = deltaTime;

		while (tryAgain && dtime > 0.0001f) {
			tryAgain = false;

			ob.update(deltaTime);
			craft.update(deltaTime);
			
			Log.e("testtest","testtest");
			if(ob.position.x < craft.position.x)
				craft.vVelocity.x-=8;
			else if(ob.position.x > craft.position.x)
				craft.vVelocity.x+=8;
			
			if(ob.position.y < craft.position.y)
				craft.vVelocity.y-=8;
			if(ob.position.y > craft.position.y)
				craft.vVelocity.y+=8;

			check = CheckForCollision(ob, craft);

			if (check == Manage_Settings.PENETRATING) {
				dtime = dtime / 2;
				tryAgain = true;
			} else if (check == Manage_Settings.COLLISION) {
				ApplyImpulse(ob, craft);
			}
		}

	}

	private void updateCycle(float deltaTime) {
		for (int j = 0; j < Manage_Settings.ObjectNumber; j++) {
			Object tO = o[j];

			tO.setCollision(CheckForCollisions(tO, deltaTime));
			tO.CalcLoads();
			tO.update(deltaTime);
		}
	}

	int CheckForCollision(RigidBody2d body1, RigidBody2d body2) {
		Math_Vector d;
		float r;
		int retval = 0;
		float s;
		Math_Vector vList1[] = new Math_Vector[4];
		Math_Vector vList2[] = new Math_Vector[4];
		float wd, lg;
		boolean haveNodeNode = false;
		boolean interpenetrating = false;
		boolean haveNodeEdge = false;
		Math_Vector v1, v2, u;
		Math_Vector edge, p, proj;
		float dist, dot;
		float Vrn; // ����

		for (int i = 0; i < 4; i++) {
			vList1[i] = new Math_Vector();
			vList2[i] = new Math_Vector();
		}

		// �켱 �ٿ����Ŭ�� �浹���θ� �˻��Ѵ�.
		r = (body1.fLength * Manage_Settings.WIDTHMULT) / 2
				+ (body2.fLength * Manage_Settings.WIDTHMULT) / 2;
		d = body1.vPosition.subNo(body2.vPosition);
		;
		s = d.len() - r;

		d.nor();

		if (s < Manage_Settings.ctol) {
			// �浹 ���ɼ��� �����Ƿ�,
			// ȣ��ũ����Ʈ�� ���� ����� �����.

			wd = (body1.fWidth * Manage_Settings.WIDTHMULT);
			lg = body1.fLength;
			vList1[0].y = wd / 2;
			vList1[0].x = lg / 2;
			vList1[1].y = -wd / 2;
			vList1[1].x = lg / 2;
			vList1[2].y = -wd / 2;
			vList1[2].x = -lg / 2;
			vList1[3].y = wd / 2;
			vList1[3].x = -lg / 2;

			for (int i = 0; i < 4; i++) {
				Math_Vector.VRotate2D(body1.fOrientation, vList1[i]);
				vList1[i] = vList1[i].addNo(body1.vPosition);
			}

			wd = (body2.fWidth * Manage_Settings.WIDTHMULT);
			lg = body2.fLength;
			vList2[0].y = wd / 2;
			vList2[0].x = lg / 2;
			vList2[1].y = -wd / 2;
			vList2[1].x = lg / 2;
			vList2[2].y = -wd / 2;
			vList2[2].x = -lg / 2;
			vList2[3].y = wd / 2;
			vList2[3].x = -lg / 2;

			for (int i = 0; i < 4; i++) {
				Math_Vector.VRotate2D(body2.fOrientation, vList2[i]);
				vList2[i] = vList2[i].addNo(body2.vPosition);
			}

			// ����-���� �浹�˻�
			for (int i = 0; i < 4 && !haveNodeNode; i++) {
				for (int j = 0; j < 4 && !haveNodeNode; j++) {
					Manage_Settings.vCollisionPoint = vList1[i];
					body1.vCollisionPoint = Manage_Settings.vCollisionPoint
							.subNo(body1.vPosition);
					body2.vCollisionPoint = Manage_Settings.vCollisionPoint
							.subNo(body2.vPosition);

					Manage_Settings.vCollisionNormal = body1.vPosition
							.subNo(body2.vPosition);
					Manage_Settings.vCollisionNormal.nor();

					v1 = body1.vVelocityBody.addNo(body1.vAngularVelocity
							.outer_productNo(body1.vCollisionPoint));
					v2 = body2.vVelocityBody.addNo(body2.vAngularVelocity
							.outer_productNo(body2.vCollisionPoint));

					v1 = Math_Vector.VRotate2D(body1.fOrientation, v1);
					v2 = Math_Vector.VRotate2D(body2.fOrientation, v2);

					Manage_Settings.vRelativeVelocity = v1.subNo(v2);
					Vrn = Manage_Settings.vRelativeVelocity
							.inner_productNo(Manage_Settings.vCollisionNormal);

					if (ArePointsEqual(vList1[i], vList2[j]) && (Vrn < 0.0f))
						haveNodeNode = true;
						
				}
			}

			// ���� - �� �浹�˻�
			if (!haveNodeNode) {
				for (int i = 0; i < 4 && !haveNodeEdge; i++) {
					for (int j = 0; j < 3 && !haveNodeEdge; j++) {
						if (j == 2)
							edge = vList2[0].subNo(vList2[j]);
						else
							edge = vList2[j + 1].subNo(vList2[j]);
						u = edge;
						u.nor();

						p = vList1[i].subNo(vList2[j]);
						proj = (p.mulNo(u)).mulNo(u);

						d = p.outer_productNo(u);
						dist = d.len();

						Manage_Settings.vCollisionPoint = vList1[i];
						body1.vCollisionPoint = Manage_Settings.vCollisionPoint
								.subNo(body1.vPosition);
						body2.vCollisionPoint = Manage_Settings.vCollisionPoint
								.subNo(body2.vPosition);

						Manage_Settings.vCollisionNormal = (u
								.outer_productNo(p)).outer_productNo(u);
						Manage_Settings.vCollisionNormal.nor();

						v1 = body1.vVelocityBody.addNo((body1.vAngularVelocity
								.outer_productNo(body1.vCollisionPoint)));
						v2 = body2.vVelocityBody.addNo((body2.vAngularVelocity
								.outer_productNo(body2.vCollisionPoint)));

						v1 = Math_Vector.VRotate2D(body1.fOrientation, v1);
						v2 = Math_Vector.VRotate2D(body2.fOrientation, v2);

						Manage_Settings.vRelativeVelocity = (v1.subNo(v2));
						Vrn = Manage_Settings.vRelativeVelocity
								.inner_productNo(Manage_Settings.vCollisionNormal);

						if ((proj.len() > 0.0f) && (proj.len() <= edge.len())
								&& (dist <= Manage_Settings.ctol)
								&& (Vrn < 0.0f))
							haveNodeEdge = true;

					}
				}
			}

			// ���뿩�� Ȯ��
			if (!haveNodeNode && !haveNodeEdge) {
				for (int i = 0; i < 4 && !interpenetrating; i++) {
					for (int j = 0; j < 4 && !interpenetrating; j++) {
						if (j == 3)
							edge = vList2[0].subNo(vList2[j]);
						else
							edge = vList2[j + 1].subNo(vList2[j]);

						p = vList1[i].subNo(vList2[j]);
						dot = p.inner_productNo(edge);

						if (dot < 0) {
							interpenetrating = true;
						}
					}
				}
			}

			if (interpenetrating) {
				retval = Manage_Settings.PENETRATING;
			} else if (haveNodeNode || haveNodeEdge) {
				retval = Manage_Settings.COLLISION;
			} else
				retval = Manage_Settings.NOEVENT;
		} else {
			retval = Manage_Settings.NOEVENT;
		}

		return retval;

	}

	boolean ArePointsEqual(Math_Vector p1, Math_Vector p2) {
		// �� �� ������ �Ÿ��� ctol �����̸� ���� ��ġ�� �ִ� ������ ����.
		if ((Math.abs(p1.x - p2.x) <= Manage_Settings.ctol)
				&& (Math.abs(p1.y - p2.y) <= Manage_Settings.ctol)
				&& (Math.abs(p1.z - p2.z) <= Manage_Settings.ctol))
			return true;
		else
			return false;
	}

	void ApplyImpulse(RigidBody2d body1, RigidBody2d body2) {
		float j;

		j = (-(1 + Manage_Settings.fCr) * (Manage_Settings.vRelativeVelocity
				.inner_productNo(Manage_Settings.vCollisionNormal)))
				/ ((1 / body1.fMass + 1 / body2.fMass)
						+ (Manage_Settings.vCollisionNormal
								.inner_productNo(((body1.vCollisionPoint
										.outer_productNo(Manage_Settings.vCollisionNormal)
										.divNo(body1.fInertia))
										.outer_productNo(body1.vCollisionPoint)))) + (Manage_Settings.vCollisionNormal
							.inner_productNo(((body2.vCollisionPoint
									.outer_productNo(Manage_Settings.vCollisionNormal))
									.divNo(body2.fInertia))
									.outer_productNo(body2.vCollisionPoint))));

		body1.vVelocity.add(Manage_Settings.vCollisionNormal.mulNo(j).divNo(
				body1.fMass));
		body1.vAngularVelocity.add(body1.vCollisionPoint.outer_productNo(
				(Manage_Settings.vCollisionNormal.mulNo(j))).divNo(
				body1.fInertia));

		body2.vVelocity.sub(Manage_Settings.vCollisionNormal.mulNo(j).divNo(
				body2.fMass));
		body2.vAngularVelocity.sub(body2.vCollisionPoint.outer_productNo(
				(Manage_Settings.vCollisionNormal.mulNo(j))).divNo(
				body2.fInertia));

		Log.e("test body2 vx :" + body2.vVelocity.x, "test body2 vy :"
				+ body2.vVelocity.y);

	}

	private boolean CheckForCollisions(Object ob, float deltaTime) {
		// ����� ź���� �˻�
		Math_Vector n = new Math_Vector();
		Math_Vector vr;
		float vrn;
		float j;
		Math_Vector fi;
		boolean hasCollision = false;

		ob.getvImpactForces().x = 0;
		ob.getvImpactForces().y = 0;

		// ������� �浹 �˻�
		if (ob.position.y <= ob.getRadious_bounds().radius) {
			n.x = 0f;
			n.y = 1f;
			vr = ob.getVelocity();
			vrn = vr.inner_productNo(n);

			if (vrn < 0.0f) {
				j = (-1) * (vr.inner_productNo(n))
						* (Manage_Settings.RESTITUTION + 1) * ob.getfMass();
				fi = n;
				fi.mul(j / 0.1f);
				ob.getvImpactForces().add(fi);

				ob.position.y = 0 + ob.getRadious_bounds().radius;
				ob.position.x = (0 + ob.getRadious_bounds().radius - ob
						.getvPreviousPosition().y)
						/ (ob.position.y - ob.getvPreviousPosition().y)
						* (ob.position.x - ob.getvPreviousPosition().x)
						+ ob.getvPreviousPosition().x;
				hasCollision = true;
			}
		}

		// ��ֹ����� �浹 �˻�

		float r;
		Math_Vector d;
		float s;

		for (int i = 0; i < Manage_Settings.ObstacleNumber; i++) {
			r = ob.getRadious_bounds().radius / 2
					+ obstacles[i].getRadious_bounds().radius / 2;
			d = ob.position.subNo(obstacles[i].position);
			s = d.len() - r;

			if (s <= 0.0f) {
				d.nor();
				n = d;
				vr = ob.getVelocity().subNo(obstacles[i].getVelocity());
				vrn = vr.inner_productNo(n);

				if (vrn < 0.0f) {

					j = (-1) * (vr.inner_productNo(n))
							* (Manage_Settings.RESTITUTION + 1)
							/ (1 / ob.getfMass() + 1 / obstacles[i].getfMass());
					fi = n;
					fi.mulNo(j / 0.1f);
					ob.getvImpactForces().add(fi);
					ob.position.sub(n.mulNo(s));
					hasCollision = true;
				}

			}
		}
		return hasCollision;
	}

	@Override
	protected void update_checkCollisions(float deltaTime) {

		for (int j = 0; j < Manage_Settings.ObjectNumber; j++) {
			Object tO = o[j];

			if (tO.position.y < 0)
				tO.position.y = Manage_Settings.GAME_HEIGHT;
			else if (tO.position.y > Manage_Settings.GAME_HEIGHT)
				tO.position.y = 0;

			if (tO.position.x < 0)
				tO.position.x = Manage_Settings.GAME_WIDTH;
			else if (tO.position.x > Manage_Settings.GAME_WIDTH)
				tO.position.x = 0;
		}

		// craft ȭ�� �˻�
		if (ob.vPosition.y < 0)
			ob.vPosition.y = Manage_Settings.GAME_HEIGHT;
		else if (ob.vPosition.y > Manage_Settings.GAME_HEIGHT)
			ob.vPosition.y = 0;

		if (ob.vPosition.x < 0)
			ob.vPosition.x = Manage_Settings.GAME_WIDTH;
		else if (ob.vPosition.x > Manage_Settings.GAME_WIDTH)
			ob.vPosition.x = 0;

		// craft2 ȭ��˻�
		if (craft.vPosition.y < 0)
			craft.vPosition.y = Manage_Settings.GAME_HEIGHT;
		else if (craft.vPosition.y > Manage_Settings.GAME_HEIGHT)
			craft.vPosition.y = 0;

		if (craft.vPosition.x < 0)
			craft.vPosition.x = Manage_Settings.GAME_WIDTH;
		else if (craft.vPosition.x > Manage_Settings.GAME_WIDTH)
			craft.vPosition.x = 0;
	}

	public Object[] getO() {
		return o;
	}

	public void setO(Object[] o) {
		this.o = o;
	}

	public int get_World_Width() {
		return this.world_Width;
	}

	public int get_World_Height() {
		return this.world_Height;
	}

	public Object[] getObstacles() {
		return obstacles;
	}

	public void setObstacles(Object[] obstacles) {
		this.obstacles = obstacles;
	}

	public RigidBody2d getOb() {
		return ob;
	}

	public void setOb(RigidBody2d ob) {
		this.ob = ob;
	}

	public RigidBody2d getCraft() {
		return craft;
	}

	public void setCraft(RigidBody2d craft) {
		this.craft = craft;
	}

}
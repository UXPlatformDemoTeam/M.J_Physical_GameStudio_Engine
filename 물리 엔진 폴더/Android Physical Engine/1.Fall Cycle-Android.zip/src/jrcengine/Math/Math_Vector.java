package jrcengine.Math;

import android.util.FloatMath;

public class Math_Vector {
	public static final float tol = 0.00001f;

	public static float TO_RADIANS = (1 / 180.0f) * (float) Math.PI;
	public static float TO_DEGREES = (1 / (float) Math.PI) * 180;
	public float x, y, z;

	public Math_Vector() {
		this.x = 0f;
		this.y = 0f;
		this.z = 0f;
	}

	public Math_Vector(float x, float y, float z) {
		this.x = x;
		this.y = y;
		this.z = z;
	}

	public Math_Vector(Math_Vector other) {
		this.x = other.x;
		this.y = other.y;
		this.z = other.z;
	}

	public Math_Vector cpy() {
		return new Math_Vector(x, y, z);
	}

	public Math_Vector set(float x, float y, float z) {
		this.x = x;
		this.y = y;
		this.z = z;
		return this;
	}

	public Math_Vector set(Math_Vector other) {
		this.x = other.x;
		this.y = other.y;
		this.z = other.z;
		return this;
	}

	public Math_Vector add(float x, float y, float z) {
		this.x += x;
		this.y += y;
		this.z += z;
		return this;
	}

	public Math_Vector add(Math_Vector other) {
		this.x += other.x;
		this.y += other.y;
		this.z += other.z;
		return this;
	}

	public Math_Vector addNo(float x, float y, float z) {
		return new Math_Vector(this.x + x, this.y + y, this.z + z);
	}

	public Math_Vector addNo(Math_Vector other) {
		return new Math_Vector(this.x + other.x, this.y + other.y, this.z
				+ other.z);
	}

	public Math_Vector sub(float x, float y, float z) {
		this.x -= x;
		this.y -= y;
		this.z -= z;
		return this;
	}

	public Math_Vector sub(Math_Vector other) {
		this.x -= other.x;
		this.y -= other.y;
		this.z -= other.z;
		return this;
	}

	public Math_Vector subNo(float x, float y, float z) {
		return new Math_Vector(this.x - x, this.y - y, this.z - z);
	}

	public Math_Vector subNo(Math_Vector other) {
		return new Math_Vector(this.x - other.x, this.y - other.y, this.z
				- other.z);
	}

	public Math_Vector mul(float scalar) {
		this.x *= scalar;
		this.y *= scalar;
		this.z *= scalar;
		return this;
	}

	public Math_Vector mul(Math_Vector other) {
		this.x *= other.x;
		this.y *= other.y;
		this.z *= other.z;
		return this;
	}

	public Math_Vector mulNo(float scalar) {
		return new Math_Vector(this.x * scalar, this.y * scalar, this.z
				* scalar);
	}

	public Math_Vector mulNo(Math_Vector other) {
		return new Math_Vector(this.x * other.x, this.y * other.y, this.z
				* other.z);
	}

	public Math_Vector div(float scalar) {
		this.x /= scalar;
		this.y /= scalar;
		this.z /= scalar;
		return this;
	}

	public Math_Vector div(Math_Vector other) {
		this.x /= other.x;
		this.y /= other.y;
		this.z /= other.z;
		return this;
	}

	public Math_Vector divNo(float scalar) {
		return new Math_Vector(this.x / scalar, this.y / scalar, this.z
				/ scalar);
	}

	public Math_Vector divNo(Math_Vector other) {
		return new Math_Vector(this.x / other.x, this.y / other.y, this.z
				/ other.z);
	}

	public float inner_product(float scalar) {
		this.x *= scalar;
		this.y *= scalar;
		this.z *= scalar;
		return x + y + z;
	}

	public float inner_product(Math_Vector other) {
		this.x *= other.x;
		this.y *= other.y;
		this.z *= other.z;
		return x + y + z;
	}

	public float inner_productNo(float scalar) {
		return this.x * scalar + this.y * scalar + this.z * scalar;
	}

	public float inner_productNo(Math_Vector other) {
		return this.x * other.x + this.y * other.y + this.z * other.z;
	}

	public Math_Vector outer_productNo(Math_Vector other) {
		return new Math_Vector(this.y * other.z - this.z * other.y, -this.x
				* other.z + this.z * other.x, this.x * other.y - this.y
				* other.x);
	}

	public float len() {
		return FloatMath.sqrt(this.x * this.x + this.y * this.y + this.z
				* this.z);
	}

	public Math_Vector nor() {
		float len = len();
		if (len <= Math_Vector.tol)
			len = 1;
		
		if (len != 0) {
			this.x /= len;
			this.y /= len;
			this.z /= len;
		}

		return this;
	}

	public boolean equals(Math_Vector other) {

		if (this.x == other.x && this.y == other.y && this.z == other.z)
			return true;

		return false;
	}

	public boolean equals(float other_x, float other_y, float other_z) {

		if (this.x == other_x && this.y == other_y && this.z == other_z) {
			return true;
		}
		return false;
	}

	public float angle() {
		float angle = (float) Math.atan2(y, x) * TO_DEGREES;
		if (angle < 0)
			angle += 360;
		return angle;
	}

	public Math_Vector rotate(float angle) {
		float rad = angle * TO_RADIANS;
		float cos = FloatMath.cos(rad);
		float sin = FloatMath.sin(rad);

		float newX = this.x * cos - this.y * sin;
		float newY = this.x * sin + this.y * cos;

		this.x = newX;
		this.y = newY;

		return this;
	}

	public Math_Vector rotateNo(float angle) {
		float rad = angle * TO_RADIANS;
		float cos = FloatMath.cos(rad);
		float sin = FloatMath.sin(rad);

		float newX = this.x * cos - this.y * sin;
		float newY = this.x * sin + this.y * cos;

		return new Math_Vector(newX, newY, 0);
	}

	public float dist(Math_Vector other) {
		float distX = this.x - other.x;
		float distY = this.y - other.y;
		float distZ = this.z - other.z;
		return FloatMath.sqrt(distX * distX + distY * distY + distZ * distZ);
	}

	public float dist(float x, float y, float z) {
		float distX = this.x - x;
		float distY = this.y - y;
		float distZ = this.z - z;
		return FloatMath.sqrt(distX * distX + distY * distY + distZ * distZ);
	}

	public float distSquared(Math_Vector other) {
		float distX = this.x - other.x;
		float distY = this.y - other.y;
		float distZ = this.z - other.z;
		return distX * distX + distY * distY + distZ * distZ;
	}

	public float distSquared(float x, float y, float z) {
		float distX = this.x - x;
		float distY = this.y - y;
		float distZ = this.z - z;
		return distX * distX + distY * distY + distZ + distZ;
	}

	public void Reverse() {
		this.x -= this.x;
		this.y -= this.y;
		this.z -= this.z;
	}

	public float TripleScalarProduct(Math_Vector u, Math_Vector v, Math_Vector w) {
		return (u.x + (v.y * w.z - v.z * w.y))
				+ (u.y * (-v.x * w.z + v.z * w.x))
				+ (u.z * (v.x * w.y - v.y * w.x));
	}

	public static float DegreesToRadians(float deg) {
		return deg * (float)Math.PI / 180.0f;
	}

	public static float RadiansToDegrees(float rad) {
		return rad * 180.0f /(float)Math.PI;
	}

}
package jrcengine.Manage;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

import jrcengine.Interface.IFace_FileIO;


public class Manage_Settings {

    public final static String file = ".ppsave";
    
    public static final int GAME_WIDTH = 240;//1024;
    public static final int GAME_HEIGHT = 160;//768;
    
    //Physics
    public static final float GRAVITYACCELERATION = -9.80665f;
    public static final float AIRDENSITY = 1.23f;
    public static final float DRAGCOEFFICIENT = 0.6f;
    public static final float WINDSPEED = 0.1f;
    
    public static final float THRUSTFORCE = 5.0f;
    public static final double rho = 0.0023769f;	// desity of air at sea level, slugs/ft^3
    public static final float  LINEARDRAGCOEFFICIENT = 1.25f;
    
    //ź�� ����
    public static final float RESTITUTION = 0.2f;
    
    //Object
    public static final int ObjectNumber = 50;
    
    //Obstacle
    public static final int ObstacleNumber = 12;
    public static final float ObstacleSize = 14f;
    
    public static void load(IFace_FileIO files) {
        BufferedReader in = null;
        try {
            in = new BufferedReader(new InputStreamReader(files.readFile(file)));
        
        } catch (IOException e) {
            // :( It's ok we have defaults
        } catch (NumberFormatException e) {
            // :/ It's ok, defaults save our day
        } finally {
            try {
                if (in != null)
                    in.close();
            } catch (IOException e) {
            }
        }
    }
    
    public static void save(IFace_FileIO iFace_FileIO) {
        BufferedWriter out = null;
        try {
            out = new BufferedWriter(new OutputStreamWriter(
                    iFace_FileIO.writeFile(file)));

        } catch (IOException e) {
        } finally {
            try {
                if (out != null)
                    out.close();
            } catch (IOException e) {
            }
        }
    }
	
}

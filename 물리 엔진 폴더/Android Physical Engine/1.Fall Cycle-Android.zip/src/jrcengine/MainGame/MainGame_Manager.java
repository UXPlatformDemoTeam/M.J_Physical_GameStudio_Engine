// �� ��ü�� ���� �ν��Ͻ��� �����ϰ�
// �� �����Ӹ��� ��ü�� ������Ʈ �ϸ� ��ü�� Bob ������ �浹�� �˻��ϰ� ������ ����
package jrcengine.MainGame;

import java.util.ArrayList;
import java.util.Random;

import jrcengine.Interface.Screen_Manager;
import jrcengine.Manage.Manage_Settings;
import jrcengine.Math.Math_Vector;
import android.util.Log;

public class MainGame_Manager extends Screen_Manager {

	private final int world_Width;
	private final int world_Height;
	private Random rnd;
	private ArrayList<Object> o;
	private Object obstacles[];
	private RigidBody2d ob;

	public MainGame_Manager(int world_Width, int world_Height) {

		this.world_Width = world_Width;
		this.world_Height = world_Height;
		this.o = new ArrayList<Object>();
		this.obstacles = new Object[Manage_Settings.ObstacleNumber];
		this.rnd = new Random();

		this.ob = new RigidBody2d(Manage_Settings.GAME_WIDTH / 2,
				Manage_Settings.GAME_HEIGHT / 2);
		ob.fOrientation = 0;

		generate();

	}

	// ���� ������ ����
	@Override
	protected void generate() {

		for (int i = 0; i < Manage_Settings.ObjectNumber; i++)
			o.add(new Object(Manage_Settings.GAME_WIDTH / 2 - 20
					+ rnd.nextInt(40), Manage_Settings.GAME_HEIGHT -10));

		for (int i = 0; i < Manage_Settings.ObstacleNumber; i++) {
			obstacles[i] = new Object(Manage_Settings.GAME_WIDTH / 2 - 50
					+ rnd.nextInt(80), Manage_Settings.GAME_HEIGHT / 2 - 20
					+ rnd.nextInt(40), Manage_Settings.ObstacleSize);
			obstacles[i].setfMass(100f);
		}

	}

	@Override
	public void update(MainGame_Renderer rander, float deltaTime,
			float accel_X, float accel_Y, float click_X, float click_Y) {

		update_Objections(deltaTime, accel_X, accel_Y, click_X, click_Y);
		update_checkCollisions(deltaTime);
	}

	@Override
	protected void update_Objections(float deltaTime, float accel_X,
			float accel_Y, float click_X, float click_Y) {
		for (int j = 0; j < o.size(); j++) {
			Object tO = o.get(j);

			tO.setCollision(CheckForCollisions(tO, deltaTime));
			tO.CalcLoads();
			tO.update(deltaTime);
		}
	}

	boolean CheckForCollisions(Object ob, float deltaTime) {
		// ����� ź���� �˻�
		Math_Vector n = new Math_Vector();
		Math_Vector vr;
		float vrn;
		float j;
		Math_Vector fi;
		boolean hasCollision = false;

		ob.getvImpactForces().x = 0;
		ob.getvImpactForces().y = 0;

		// ������� �浹 �˻�
		if (ob.position.y <= ob.getRadious_bounds().radius) {
			n.x = 0f;
			n.y = 1f;
			vr = ob.getVelocity();
			vrn = vr.inner_productNo(n);

			if (vrn < 0.0f) {
				j = (-1) * (vr.inner_productNo(n))
						* (Manage_Settings.RESTITUTION + 1) * ob.getfMass();
				fi = n;
				fi.mul(j / 0.1f);
				ob.getvImpactForces().add(fi);

				ob.position.y = 0 + ob.getRadious_bounds().radius;
				ob.position.x = (0 + ob.getRadious_bounds().radius - ob
						.getvPreviousPosition().y)
						/ (ob.position.y - ob.getvPreviousPosition().y)
						* (ob.position.x - ob.getvPreviousPosition().x)
						+ ob.getvPreviousPosition().x;
				hasCollision = true;
			}
		}

		// ��ֹ����� �浹 �˻�

		float r;
		Math_Vector d;
		float s;

		for (int i = 0; i < Manage_Settings.ObstacleNumber; i++) {
			r = ob.getRadious_bounds().radius / 2
					+ obstacles[i].getRadious_bounds().radius / 2;
			d = ob.position.subNo(obstacles[i].position);
			s = d.len() - r;

			if (s <= 0.0f) {
				d.nor();
				n = d;
				vr = ob.getVelocity().subNo(obstacles[i].getVelocity());
				vrn = vr.inner_productNo(n);

				if (vrn < 0.0f) {
					
						j = (-1) * (vr.inner_productNo(n))
							* (Manage_Settings.RESTITUTION + 1)
							/ (1 / ob.getfMass() + 1 / obstacles[i].getfMass());
					fi = n;
					fi.mulNo(j/0.1f);
					ob.getvImpactForces().add(fi);
					ob.position.sub(n.mulNo(s));
					hasCollision = true;
				}

			}
		}
		return hasCollision;
	}

	@Override
	protected void update_checkCollisions(float deltaTime) {
		for (int j = 0; j < o.size(); j++) {
			Object tO = o.get(j);

			if (tO.position.y < 0)
				tO.position.y = Manage_Settings.GAME_HEIGHT;
			else if (tO.position.y > Manage_Settings.GAME_HEIGHT)
				tO.position.y = 0;

			if (tO.position.x < 0)
				tO.position.x = Manage_Settings.GAME_WIDTH;
			else if (tO.position.x > Manage_Settings.GAME_WIDTH)
				tO.position.x = 0;
		}
	}

	public ArrayList<Object> getO() {
		return o;
	}

	public void setO(ArrayList<Object> o) {
		this.o = o;
	}

	public int get_World_Width() {
		return this.world_Width;
	}

	public int get_World_Height() {
		return this.world_Height;
	}

	public Object[] getObstacles() {
		return obstacles;
	}

	public void setObstacles(Object[] obstacles) {
		this.obstacles = obstacles;
	}

}
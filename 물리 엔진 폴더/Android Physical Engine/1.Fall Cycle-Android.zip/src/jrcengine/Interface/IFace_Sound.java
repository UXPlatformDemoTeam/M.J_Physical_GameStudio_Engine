package jrcengine.Interface;

public interface IFace_Sound {
	public void play(float volume);

	public void dispose();
}

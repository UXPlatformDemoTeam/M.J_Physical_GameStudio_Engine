package jrcengine.Basic;

import jrcengine.Interface.IFace_Handler_Accelerometer;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;

public class Handler_Accelerometer implements IFace_Handler_Accelerometer,
		SensorEventListener {
	protected float accelX;
	protected float accelY;
	protected float accelZ;

	public Handler_Accelerometer(Context context) {
		SensorManager manager = (SensorManager) context
				.getSystemService(Context.SENSOR_SERVICE);
		if (manager.getSensorList(Sensor.TYPE_ACCELEROMETER).size() != 0) {
			Sensor accelerometer = manager.getSensorList(
					Sensor.TYPE_ACCELEROMETER).get(0);
			manager.registerListener(this, accelerometer,
					SensorManager.SENSOR_DELAY_GAME);
		}
	}

	public void onAccuracyChanged(Sensor sensor, int accuracy) {
		// stubs method ��� ��ɵ� ���� ���� �ʴ´�.
	}

	public void onSensorChanged(SensorEvent event) {
		  accelX = event.values[0];
	      accelY = event.values[1];
	      accelZ = event.values[2];
	}

	public float getAccelX() {
		return accelX;
	}

	public float getAccelY() {
		return accelY;
	}

	public float getAccelZ() {
		return accelZ;
	}
}

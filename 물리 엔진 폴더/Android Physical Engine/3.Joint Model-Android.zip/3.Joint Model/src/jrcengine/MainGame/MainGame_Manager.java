// �� ��ü�� ���� �ν��Ͻ��� �����ϰ�
// �� �����Ӹ��� ��ü�� ������Ʈ �ϸ� ��ü�� Bob ������ �浹�� �˻��ϰ� ������ ����
package jrcengine.MainGame;

import java.util.Random;

import jrcengine.Interface.Screen_Manager;
import jrcengine.Manage.Manage_Settings;
import jrcengine.Math.Math_Vector;

public class MainGame_Manager extends Screen_Manager {

	private final int world_Width;
	private final int world_Height;
	private Object objects[];
	private Spring springs[];

	public MainGame_Manager(int world_Width, int world_Height) {

		this.world_Width = world_Width;
		this.world_Height = world_Height;
		this.objects = new Object[Manage_Settings._OBJECT_NUMBER];
		this.springs = new Spring[Manage_Settings._SPRING_NUMBER];
		
		for(int i = 0 ; i < Manage_Settings._OBJECT_NUMBER ; i++)
			this.objects[i] = new Object(0, 0);
		
		for(int i = 0 ; i < Manage_Settings._SPRING_NUMBER ; i++)
			this.springs[i] = new Spring();

		generate();

	}

	// ���� ������ ����
	@Override
	protected void generate() {
		Math_Vector r;

		this.getObjects()[0].setLocked(true);
		this.getObjects()[Manage_Settings._OBJECT_NUMBER-1].setLocked(true);

		// ���ʿ��� ���������� ��ƼŬ�� �ʱ�ȭ
		for (int i = 0; i < Manage_Settings._OBJECT_NUMBER; i++) {
			this.getObjects()[i].position.x = Manage_Settings.GAME_WIDTH / 2
					+ this.getObjects()[i].getfRadius() * i;
			this.getObjects()[i].position.y = Manage_Settings.GAME_HEIGHT / 2+ 100;
		}

		// ���ʿ��� ���������� ��ƼŬ�� ����� �������� �ʱ�ȭ
		for (int i = 0; i < Manage_Settings._SPRING_NUMBER; i++) {
			getSprings()[i].setnEnd1(i);
			getSprings()[i].setnEnd2(i + 1);
			r = this.getObjects()[i + 1].position
					.subNo(this.getObjects()[i].position);
			getSprings()[i].setfInitialLength(r.len());
			getSprings()[i].setfK(Manage_Settings._SPRING_K);
			getSprings()[i].setfD(Manage_Settings._SPRING_D);
		}

	}

	@Override
	public void update(MainGame_Renderer rander, float deltaTime,
			float accel_X, float accel_Y, float click_X, float click_Y) {

		update_Objections(deltaTime, accel_X, accel_Y, click_X, click_Y);
		update_checkCollisions(deltaTime);
	}

	@Override
	protected void update_Objections(float deltaTime, float accel_X,
			float accel_Y, float click_X, float click_Y) {

		// �� ��ü�� �ۿ��ϴ� ź������ 0���� �ʱ�ȭ
		for (int i = 0; i < Manage_Settings._OBJECT_NUMBER; i++)
			getObjects()[i].setvSprings(new Math_Vector(0, 0, 0));

		for (int i = 0; i < Manage_Settings._SPRING_NUMBER; i++) {
			int j;
			double dl, f;
			Math_Vector pt1, pt2;
			Math_Vector r, F;
			Math_Vector v1, v2, vr;

			j = getSprings()[i].getnEnd1();
			pt1 = getObjects()[j].position;
			v1 = getObjects()[j].getVelocity();

			j = getSprings()[i].getnEnd2();
			pt2 = getObjects()[j].position;
			v2 = getObjects()[j].getVelocity();

			vr = v2.subNo(v1);
			r = pt2.subNo(pt1);
			dl = r.len() - getSprings()[i].getfInitialLength();
			f = getSprings()[i].getfK() * dl;
			r.nor();

			F = r.mulNo((float) f)
					.addNo(r.mulNo(vr.mul(getSprings()[i].getfD())
							.inner_productNo(r)));
			j = getSprings()[i].getnEnd1();
			
			if(getObjects()[j].isLocked() == false)
				getObjects()[j].getvSprings().add(F);
			
			j = getSprings()[i].getnEnd2();
			if(getObjects()[j].isLocked() == false)
				getObjects()[j].getvSprings().sub(F);
			
		}
		
		// ���б�
		for (int i = 0; i < Manage_Settings._OBJECT_NUMBER; i++) {
			Object _object = getObjects()[i];

			_object.CalcLoads();
			_object.update(deltaTime);
		}
	}


	@Override
	protected void update_checkCollisions(float deltaTime) {
		for (int i = 0; i < Manage_Settings._OBJECT_NUMBER; i++) {
			Object tO = getObjects()[i];

			if (tO.position.y < 0)
				tO.position.y = Manage_Settings.GAME_HEIGHT;
			else if (tO.position.y > Manage_Settings.GAME_HEIGHT)
				tO.position.y = 0;

			if (tO.position.x < 0)
				tO.position.x = Manage_Settings.GAME_WIDTH;
			else if (tO.position.x > Manage_Settings.GAME_WIDTH)
				tO.position.x = 0;
		}
	}

	public int get_World_Width() {
		return this.world_Width;
	}

	public int get_World_Height() {
		return this.world_Height;
	}

	public Object[] getObjects() {
		return objects;
	}

	public void setObjects(Object[] objects) {
		this.objects = objects;
	}

	public Spring[] getSprings() {
		return springs;
	}

	public void setSprings(Spring[] springs) {
		this.springs = springs;
	}

}
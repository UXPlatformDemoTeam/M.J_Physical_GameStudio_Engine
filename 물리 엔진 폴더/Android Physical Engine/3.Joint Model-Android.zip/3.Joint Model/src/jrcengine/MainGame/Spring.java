package jrcengine.MainGame;

public class Spring{
	private int nEnd1;
	private int nEnd2;
	private float fK;
	private float fD;
	private float fInitialLength;

	public int getnEnd1() {
		return nEnd1;
	}

	public void setnEnd1(int nEnd1) {
		this.nEnd1 = nEnd1;
	}

	public int getnEnd2() {
		return nEnd2;
	}

	public void setnEnd2(int nEnd2) {
		this.nEnd2 = nEnd2;
	}

	public float getfK() {
		return fK;
	}

	public void setfK(float fK) {
		this.fK = fK;
	}

	public float getfD() {
		return fD;
	}

	public void setfD(float fD) {
		this.fD = fD;
	}

	public float getfInitialLength() {
		return fInitialLength;
	}

	public void setfInitialLength(float fInitialLength) {
		this.fInitialLength = fInitialLength;
	}
	
	
	
}
package jrcengine.MainGame;

import jrcengine.Interface.Object_Dynamic;
import jrcengine.Manage.Manage_Settings;
import jrcengine.Math.Math_Vector;

public class Object extends Object_Dynamic {

	private float fSpeed; // �ӷ�/ ���ӵ�
	private float fMass;
	private Math_Vector Gravity;
	private Math_Vector vPreviousPosition;
	private Math_Vector vImpactForces;
	private Math_Vector vSprings;
	private boolean isLocked;
	private boolean isCollision;

	public Object(float center_x, float center_y) {
		super(center_x, center_y, 2f);
		// TODO Auto-generated constructor stub
		this.setfMass(1.0f);
		this.position = new Math_Vector(0f, 0f, 0f);
		this.vImpactForces = new Math_Vector(0f, 0f, 0f);
		this.setVelocity(new Math_Vector(0f, 0f, 0f));
		this.setfSpeed(0f);
		this.setAccel(new Math_Vector(0f, 0f, 0f));
		this.setGravity(new Math_Vector(0, getfMass()
				* Manage_Settings.GRAVITYACCELERATION, 0f));
		this.setvPreviousPosition(new Math_Vector());
		this.setLocked(false);
	}

	public Object(float center_x, float center_y, float radius) {
		super(center_x, center_y, radius);
		// TODO Auto-generated constructor stub
		this.setfMass(1.0f);
		this.position = new Math_Vector(0f, 0f, 0f);
		this.setVelocity(new Math_Vector(0f, 0f, 0f));
		this.setfSpeed(0f);
		this.setAccel(new Math_Vector(0f, 0f, 0f));
		this.setGravity(new Math_Vector(0, getfMass()
				* Manage_Settings.GRAVITYACCELERATION, 0f));
		this.setvPreviousPosition(new Math_Vector());
		this.setLocked(false);
	}

	// ��� ���� ����ϴ� Method
	public void CalcLoads() {

		this.getAccel().x = 0.0f;
		this.getAccel().y = 0.0f;

		if (isCollision()) {
			// ���� �����ϸ�
			getAccel().add(vImpactForces);
		} else {

			// Gravity
			if (this.isLocked() == false) {
				getAccel().add(getGravity());
				getAccel().add(getvSprings());

				// Stiil Air drag
				Math_Vector vDrag = new Math_Vector(0f, 0f, 0f);
				float fDrag = 0f;

				vDrag.sub(velocity);
				vDrag.nor();
				fDrag = 0.5f * Manage_Settings.AIRDENSITY * getfSpeed()
						* getfSpeed() * ((float) Math.PI * 0.1f * 0.1f)
						* Manage_Settings.DRAGCOEFFICIENT;
				vDrag.mul(fDrag);
				accel.add(vDrag);

				Math_Vector vWind = new Math_Vector(0f, 0f, 0f);
				vWind.x = 0.5f * Manage_Settings.AIRDENSITY
						* Manage_Settings.WINDSPEED * Manage_Settings.WINDSPEED
						* ((float) Math.PI * 0.1f * 0.1f)
						* Manage_Settings.DRAGCOEFFICIENT;

				accel.add(vWind);

			}

		}
	}

	// ���б�
	public void update(float deltaTime) {

		Math_Vector a;
		Math_Vector dv;
		Math_Vector ds;

		// Save the previous position
		// vPreviousPosition = position;
		a = getAccel().divNo(fMass);

		dv = a.mulNo(deltaTime);
		getVelocity().add(dv);
		ds = getVelocity().mulNo(deltaTime);
		position.add(ds);

		setfSpeed(getVelocity().len());
	}
	
	void drawObjectLine(Math_Vector tposition)
	{
		// Draw Line Function
	}

	// getter setter

	public float getfSpeed() {
		return fSpeed;
	}

	public void setfSpeed(float fSpeed) {
		this.fSpeed = fSpeed;
	}

	public float getfMass() {
		return fMass;
	}

	public void setfMass(float fMass) {
		this.fMass = fMass;
	}

	public Math_Vector getGravity() {
		return Gravity;
	}

	public void setGravity(Math_Vector gravity) {
		Gravity = gravity;
	}

	public Math_Vector getvPreviousPosition() {
		return vPreviousPosition;
	}

	public void setvPreviousPosition(Math_Vector vPreviousPosition) {
		this.vPreviousPosition = vPreviousPosition;
	}

	public boolean isLocked() {
		return isLocked;
	}

	public void setLocked(boolean isLocked) {
		this.isLocked = isLocked;
	}

	public boolean isCollision() {
		return isCollision;
	}

	public void setCollision(boolean isCollision) {
		this.isCollision = isCollision;
	}

	public Math_Vector getvImpactForces() {
		return vImpactForces;
	}

	public void setvImpactForces(Math_Vector vImpactForces) {
		this.vImpactForces = vImpactForces;
	}

	public Math_Vector getvSprings() {
		return vSprings;
	}

	public void setvSprings(Math_Vector vSprings) {
		this.vSprings = vSprings;
	}

}

package jrcengine.Interface;

import jrcengine.MainGame.MainGame_Renderer;

abstract public class Screen_Manager {

	public Screen_Manager() {

	}

	abstract protected void generate();

	abstract public void update(MainGame_Renderer rander, float deltaTime,
			float accel_X, float accel_Y, float click_X, float click_Y);
	abstract protected void update_Objections(float deltaTime, float accel_X,
			float accel_Y, float click_X, float click_Y);
	abstract protected void update_checkCollisions(float deltaTime);

}

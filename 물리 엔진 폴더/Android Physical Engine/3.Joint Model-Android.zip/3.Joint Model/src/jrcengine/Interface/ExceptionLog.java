package jrcengine.Interface;

public interface ExceptionLog {

}

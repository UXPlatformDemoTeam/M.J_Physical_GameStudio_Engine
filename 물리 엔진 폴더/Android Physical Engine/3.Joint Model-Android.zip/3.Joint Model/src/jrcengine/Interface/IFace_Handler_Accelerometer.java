package jrcengine.Interface;

public interface IFace_Handler_Accelerometer {

}

package jrcengine.Interface;

public interface IFace_Audio {
	public IFace_Music newMusic(String filename);

	public IFace_Sound newSound(String filename);
}
